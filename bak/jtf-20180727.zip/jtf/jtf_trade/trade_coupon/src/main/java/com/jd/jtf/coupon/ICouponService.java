package com.jd.jtf.coupon;

public interface ICouponService {
}
