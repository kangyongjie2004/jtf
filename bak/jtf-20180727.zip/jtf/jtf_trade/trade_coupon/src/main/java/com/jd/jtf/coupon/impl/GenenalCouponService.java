package com.jd.jtf.coupon.impl;

import com.jd.jtf.coupon.ICouponService;

public class GenenalCouponService implements ICouponService {
}
