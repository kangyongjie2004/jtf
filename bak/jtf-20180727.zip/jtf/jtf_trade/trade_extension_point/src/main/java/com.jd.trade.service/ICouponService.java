package com.jd.trade.service;


public interface ICouponService {

    float getCoupon(String orderId);

}
