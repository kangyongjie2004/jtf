package com.jd.trade.service;

public interface IPriceService {
    public float getPrice(String skuid);
}
