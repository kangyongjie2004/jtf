package com.jd.jtf.demo.plugin;

import org.springframework.stereotype.Service;

/**
 * =========================================================
 * 京东 - 技术拓展研发部 - 智能研发组
 * 类说明：
 *
 * @author kangyongjie E-mail: kangyongjie@jd.com
 * @version Created ：2018/7/16 15:22
 */
@Service
public class PrintService {

    public void print(){
        System.out.println("Hello ,world. ... ...");
    }
}
