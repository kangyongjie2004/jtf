package com.jd.jtf.demo.plugin.test;

/**
 * =========================================================
 * 京东 - 技术拓展研发部 - 智能研发组
 * 类说明：
 *
 * @author kangyongjie E-mail: kangyongjie@jd.com
 * @version Created ：2018/7/24 17:48
 */
public class Test {
    public void print(){
        System.out.println("hello,world!");
    }
}
